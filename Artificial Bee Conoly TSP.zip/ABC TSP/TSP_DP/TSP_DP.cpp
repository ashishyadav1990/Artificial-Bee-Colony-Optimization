#include <iostream>
#include <cstring>
#include<stdlib.h>
#include <ctime>
using namespace std;
#define maxn 30
#define INF 1000000000
int mat[maxn][maxn], N;
int dp[21][(1<<20)+5];

void doit(int u, int s)
{
    cout << u << " ";
    if(s==0)
    {
        return;
    }

    int id = -1, mx = INF;
    for(int i=0; i<N; ++i)
    {
        if(s&(1<<i))
        {
            int dis = mat[u][i] + dp[i][s^(1<<i)];
            if(mx > dis) mx = dis, id = i;

        }
    }
    doit(id, s^(1<<id));

}

int tsp(int u, int s)
{
    if(s==0)
    {
        return mat[u][0];
    }
    if(dp[u][s] > -1)
        return dp[u][s];
    dp[u][s] = INF;
    for(int i=0; i<N; ++i)
    {
        if(s&(1<<i))
        {
            dp[u][s] = min(dp[u][s],
                           mat[u][i] + tsp(i, s^(1<<i)));
        }
    }
    return dp[u][s];
}
int main()
{
    srand(time(0));
    int i,j;
    memset(dp, -1, sizeof(dp));
    cin >> N;
    for(i=0; i<N; ++i)
      for(j=0; j<N; ++j)
         mat[i][j] = -1; //no edge present

    for(i=0; i<N; ++i)
    {
      for(j=i; j<N; ++j)
      {
            mat[i][j] = 1+rand()%100;
            mat[j][i] = mat[i][j];

      }
    }
    for(i=0;i<N;i++)
    mat[i][i]=0;

    clock_t t=clock();
    cout << tsp(0,(1<<N)-2);
    cout << endl;
    doit(0, (1<<N)-2);
    t=clock()-t;
    cout<<"\n\n";
    cout<<"Number of clicks is "<<t<<"and time in sec is "<<(float)t/CLOCKS_PER_SEC;
    return 0;
}
